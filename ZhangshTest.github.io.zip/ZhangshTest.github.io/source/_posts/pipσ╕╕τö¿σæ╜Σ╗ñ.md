---
title: pip常用命令
date: 2018-12-17 20:21:00
categories: 
    - 教程
tags:
    - Python
cover: /img/pip.png
---

pip 是一个现代的，通用的 Python 包管理工具。提供了对 Python 包的查找、下载、安装、卸载的功能

你可以通过以下命令来判断是否已安装：
```
pip --version
```

### 安装包
```
pip install SomePackage
```

### 查看已安装的包
```
pip show --files SomePackage 或 pip show -f SomePackage
```

### pip检查哪些包需要更新
```
pip list --outdated 或 pip list -o
```

### pip升级包
升级指定的包，通过使用==, >=, <=, >, < 来指定一个版本号
```
pip install --upgrade SomePackage 或 pip install -U SomePackage
```

### pip卸载包
```
pip uninstall SomePackage
```
