---
title: Homebrewd教程
date: 2018-12-09 16:38:44
categories: 
    - 教程
tags: 
    - Mac
cover: /img/brew.png
---

Homebrew-macOS 缺失的软件包的管理器

[Homebrew官网](https://brew.sh/index_zh-cn.html)


### Homebrew安装
安装，打开终端，复制粘贴，大约1分钟左右，下载完成，过程中需要输入密码，其他无需任何操作：
```
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

### Homebrew卸载
```
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/uninstall)"
```

### Homebrew更新
```
更新Homebrew: brew update
```

### Homebrew常用命令
```
安装软件，如：brew install oclint
卸载软件，如：brew uninstall oclint
搜索软件，如：brew search oclint
更新软件，如：brew upgrade oclint
查看安装列表， 如：brew list
```

### Homebrew包更新

更新之前，`brew outdated` 查看哪些包可以更新。

用 `brew upgrade` 去更新了。`Homebrew` 会安装新版本的包，但旧版本仍然会保留。
```
brew upgrade # 更新所有的包 
brew upgrade $FORMULA # 更新指定的包 
```
清理旧版本 一般情况下，新版本安装了，旧版本就不需要了。`brew cleanup` 清理旧版本和缓存文件。`Homebrew` 只会清除比当前安装的包更老的版本，所以不用担心有些包没更新但被删了。
```
brew cleanup # 清理所有包的旧版本 
brew cleanup $FORMULA # 清理指定包的旧版本 
brew cleanup -n # 查看可清理的旧版本包，不执行实际操作 
```
这样一套下来，该更新的都更新了，旧版本也被清理了。


### 锁定不想更新的包 
`brew pin` 去锁定这个包，然后 `brew update` 就会略过它了。
```
brew pin FORMULA      # 锁定某个包  
brew unpinFORMULA # 取消锁定 
```
其他几个常用命令
```
brew info $FORMULA # 显示某个包的信息 
brew info # 显示安装了包数量，文件数量，和总占用空间 
brew deps 可以显示包的依赖关系，我常用它来查看已安装的包的依赖，然后判断哪些包是可以安全删除的。
brew deps –installed –tree # 查看已安装的包的依赖，树形显示
```

