---
title: rarosx-Mac下rar命令解压和压缩
date: 2018-12-09 22:38:00
categories: 
    - 教程
tags: 
    - Mac
cover: /img/timthumb29.jpg
---

### 下载rarosx

[下载地址](https://www.rarlab.com/download.htm)
```
解压缩：tar zxvf rarosx-5.4.0.tar.gz 
```


### 安装rar和unrar命令
```
sudo install -c -o $USER rar /usr/local/bin/  ＃安装rar
sudo install -c -o $USER unrar /usr/local/bin  ＃安装unrar
```

如果安装失败可以看看/usr/local/bin 目录是不是存在rar或unrar的软链接


### 利用rar和unrar压缩和解压文件
rar和unrar文件的参数也很多，就不在一一介绍了，直接在Ternimal执行对应命令就能看到所有参数选项，下面列举几个常用的

```
解压文件：unrar x test.rar
压缩文件A和B：rar a 压缩后.rar A B
```