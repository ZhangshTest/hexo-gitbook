---
title: 优雅的使用Sublime Text 3
date: 2018-12-17 21:41:08
categories: 
    - 工具
tags:
    - Mac
cover: /img/sublime.png
---

Sublime Text 3：一款具有代码高亮、语法提示、自动完成且反应快速的编辑器软件，不仅具有华丽的界面，还支持插件扩展机制。相比于难于上手的Vim，浮肿沉重的Eclipse，VS，即便体积轻巧迅速启动的Editplus、Notepad++，在SublimeText面前大略显失色，无疑这款性感无比的编辑器是Coding和Writing最佳的选择，没有之一。


## Sublime Text 3的注册码 

11.20版本

```
----- BEGIN LICENSE -----
sgbteam
Single User License
EA7E-1153259
8891CBB9 F1513E4F 1A3405C1 A865D53F
115F202E 7B91AB2D 0D2A40ED 352B269B
76E84F0B CD69BFC7 59F2DFEF E267328F
215652A3 E88F9D8F 4C38E3BA 5B2DAAE4
969624E7 DC9CD4D5 717FB40C 1B9738CF
20B3C4F1 E917B5B3 87C38D9C ACCE7DD8
5F7EF854 86B9743C FADC04AA FB0DA5C0
F913BE58 42FEA319 F954EFDD AE881E0B
------ END LICENSE ------
```

## Sublime Text 3插件推荐

### MarkDown Editing
Sublime Text 3虽然能够查看和编辑 Markdown 文件，但它会视它们为格式很糟糕的纯文本。这个插件通过适当的颜色高亮和其它功能来更好地完成这些任务。


### terminal
terminal插件可以让你在Sublime中直接使用终端打开你的项目文件夹，并支持使用快捷键 `ctrl+shift+T`。
```
ctrl+shift+t     打开文件所在文件夹，
ctrl+shift+alt+t 打开文件所在项目的根目录文件夹
```

### Doc​Blockr
Doc​Blockr可以快速的对函数进行注释。保持代码规范。支持多种语言,有 JavaScript (including ES6), PHP, ActionScript, Haxe, CoffeeScript, TypeScript, Java, Apex, Groovy, Objective C, C, C++ and Rust.

```
/*   回车创建一个代码块注释
/**  回车在自动查找函数中的形参等等。
```
它会生成 JSDoc 格式的注释。如果你从没有使用过类似的工具，DocBlockr 会让你觉得以前没有它是如何写代码的。帮助你创造你的代码注释，通过解析功能，参数，变量，并且自动添加基本项目；

### sublime-text-git: 
Git 版本控制,可视化的操作：帮助你与你的Git repo协议进行交互。它支持很多命令像init,push, pull, branch, stash,等等。使用它当然提前需要安装 Git，并做好响应的配置；


### Bracket Highlighter 
Bracket Highlighter 用于匹配括号，引号和html标签。对于很长的代码很有用。安装好之后，不需要设置插件会自动生效

#### 先介绍到这里，以后再补充...

