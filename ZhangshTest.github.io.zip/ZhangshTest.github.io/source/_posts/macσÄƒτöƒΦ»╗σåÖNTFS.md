---
title: mac原生读写NTFS
date: 2019-06-08 17:06:22
categories: 
    - 教程
tags:
    - Mac
cover: /img/ntfs.png
---

## 查看磁盘的Volume Name
打开 terminal 执行`diskutil list` 查看volume name
![](/img/ntfs1.png)
可以看到我的volume name是My Passport

## 更改 /etc/fstab文件
更新 `/etc/fstab`文件，在terminal 执行 `sudo vi /etc/fstab` 打开文件fstab，写入下面内容：
```
LABEL=My\040Passport none ntfs rw,auto,nobrowse
```
`My\040Passport`,代表的磁盘的`volume name`（如果你的`volume name`里有空格，则需用`\040`的意思是代替空格键)。 
后面的`Ntfs rw`表示把这个分区挂载为可读写的`ntfs格式`。 
最后`nobrowse`非常重要，因为这个代表了在`finder`里不显示这个分区，这个选项非常重要，如果不打开的话挂载是不会成功的。

## 做快捷方式
这儿有个缺陷需要去掉：因为这个分区在`finder`里不显示了，那么我们要怎么找到它呢，总不能一直用命令行。 
解决办法其实很简单，因为这个`My Paaport`分区是挂`/Volumes`下的，我们把这个目录在桌面做一个快捷方式就行了。
```
sudo ln -s /Volumes/My Passport ~/Desktop/lhldisk
```
![](/img/ntfs2.png)

## 隐藏桌面移动硬盘快捷方式，拖入Finder边栏
将快捷方式lhldisk拖入边栏
![](/img/ntfs3.png)
拖入后结果 
![](/img/ntfs5.png)
而后隐藏桌面移动硬盘快捷方式，打开terminal，执行
```
cd ~/Desktop
mv lhldisk .lhldisk
```