---
title: git教程
date: 2018-12-09 15:03:25
categories: 
    - 教程
tags: git
cover: /img/git.png
---

Git是一个开源的分布式版本控制系统，用于敏捷高效地处理任何或小或大的项目。Git 是 Linus Torvalds 为了帮助管理 Linux 内核开发而开发的一个开放源码的版本控制软件。Git 与常用的版本控制工具 CVS, Subversion 等不同，它采用了分布式版本库的方式，不必服务器端软件支持。

### Git 与 SVN 区别
> GIT不仅仅是个版本控制系统，它也是个内容管理系统(CMS),工作管理系统等。如果你是一个具有使用SVN背景的人，你需要做一定的思想转换，来适应GIT提供的一些概念和特征。

Git 与 SVN 区别点：

1. GIT是分布式的，SVN不是：这是GIT和其它非分布式的版本控制系统，例如SVN，CVS等，最核心的区别。
2. GIT把内容按元数据方式存储，而SVN是按文件：所有的资源控制系统都是把文件的元信息隐藏在一个类似.svn,.cvs等的文件夹里。
3. GIT分支和SVN的分支不同：分支在SVN中一点不特别，就是版本库中的另外的一个目录。
4. GIT没有一个全局的版本号，而SVN有：目前为止这是跟SVN相比GIT缺少的最大的一个特征。
5. GIT的内容完整性要优于SVN：GIT的内容存储使用的是SHA-1哈希算法。这能确保代码内容的完整性，确保在遇到磁盘故障和网络问题时降低对版本库的破坏。

### 入门
使用Git前，需要先建立一个仓库(repository)。您可以使用一个已经存在的目录作为Git仓库或创建一个空目录。

使用您当前目录作为Git仓库，我们只需使它初始化。
```
git init
```
使用我们指定目录作为Git仓库。
```
git init newrepo
```
从现在开始，我们将假设您在Git仓库根目录下，除非另有说明。

### 添加新文件
我们有一个仓库，但什么也没有，可以使用add命令添加文件。
```
git add filename
```
可以使用add... 继续添加任务文件。

### 提交版本
现在我们已经添加了这些文件，我们希望它们能够真正被保存在Git仓库。

为此，我们将它们提交到仓库。
```
git commit -m "Adding files"
```
如果您不使用-m，会出现编辑器来让你写自己的注释信息。

当我们修改了很多文件，而不想每一个都add，想commit自动来提交本地修改，我们可以使用-a标识。
```
git commit -a -m "Changed some files"
git commit 命令的-a选项可将所有被修改或者已删除的且已经被git管理的文档提交到仓库中。
```
千万注意，-a不会造成新文件被提交，只能修改。

### 发布版本
我们先从服务器克隆一个库并上传。
```
git clone ssh://example.com/~/www/project.git
```
现在我们修改之后可以进行推送到服务器。
```
git push ssh://example.com/~/www/project.git
```
### 取回更新
如果您已经按上面的进行push，下面命令表示，当前分支自动与唯一一个追踪分支进行合并。
```
git pull
```
从非默认位置更新到指定的url。
```
git pull http://git.example.com/project.git
```

### 删除
如何你想从资源库中删除文件，我们使用rm。
```
git rm file
```
### 分支与合并
分支在本地完成，速度快。要创建一个新的分支，我们使用branch命令。
```
git branch test
```
branch命令不会将我们带入分支，只是创建一个新分支。所以我们使用checkout命令来更改分支。
```
git checkout test
```
第一个分支，或主分支，被称为"master"。
```
git checkout master
```
对其他分支的更改不会反映在主分支上。如果想将更改提交到主分支，则需切换回master分支，然后使用合并。
```
git checkout master
git merge test
```
### 删除分支，我们使用-d标识。
```
git branch -d test
```

### 配置github

```
生成SSH: ssh-keygen -t rsa -C "your_email" 
```
`your_email`改为你在`github`上注册的邮箱，之后会要求确认路径和输入密码，我们这使用默认的一路回车就行。成功的话会在`~/下生成.ssh文件夹`，进去，打开`id_rsa.pub`，复制里面的`key`。回到`github`上，进入 `Account Settings（账户配置）`，左边选择`SSH Keys`，`Add SSH Key`,`title`随便填，粘贴在你电脑上生成的`key`。

```
输入以下命令验证是否成功： ssh -T git@github.com
WW
```
```
git config --global user.name "user.name" 
git config --global user.email "user.email" 
git config user.name //查看用户名 git init //创建本地代码库 

其他：
ls -al //查看全部文件
git add 文件 //添加文件 
git commit -m "备注" //提交
git ststus //查看修改的部分 
git diff //查看具体修改了什么，q键退回命令行输入 
git log //查看提交信息 

忽略: 在根目录下建.gitignore文件，可以提交时忽略文件中的内容

```