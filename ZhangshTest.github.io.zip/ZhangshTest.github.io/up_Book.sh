#!/bin/sh
cd /Users/zhang_sh/Desktop/code/ZhangshTest/ZhangshTest.github.io/book
# hexo clean
hexo g
gitbook build ./ ../public/book
hexo d